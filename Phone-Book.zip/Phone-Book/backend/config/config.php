<?php

$config = [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '',
    'database' => 'farmmarket'
];